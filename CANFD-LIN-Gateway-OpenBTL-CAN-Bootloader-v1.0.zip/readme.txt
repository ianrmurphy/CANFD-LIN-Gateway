CAN FD LIN Gateway - OpenBTL CAN Bootloader

Description
The binary file contains a compiled OpenBTL bootloader for the CANFD LIN Gateway.
Bootloader is available over CAN1 channel of the device.

MACH SYSTEMS s.r.o.
www.machsystems.cz
